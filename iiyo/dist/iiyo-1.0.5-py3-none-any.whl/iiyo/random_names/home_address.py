sadasiri Niwasa 12/A
word Place 401 2/A
Amal Niwasa 1st Lane
27 Z/1 New Road
Wewa Rauma para 
Lake Road 4/5
Main Road
Cross Road
Temple Road
Pansala Para
School Road
Star Apatment
Sir Chitthampalam A Gardiner Mawatha