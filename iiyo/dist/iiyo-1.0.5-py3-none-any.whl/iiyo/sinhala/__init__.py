import random
from .Data import *


# prastha_pirulu
def prasthapirulu():
    return random.choice(Prastha_Pirulu_List)


# prastha_pirulu
def pp():
    return random.choice(Prastha_Pirulu_List)


# theravili
def theravili():
    return random.choice(theravili_List)


# thun_theravili
def thun_theravili():
    return random.choice(thun_theravili_List)


# thun_theravili shorts
def thun():
    return random.choice(thun_theravili_List)
