﻿iiyo is Sinhala Prastha Pirulu Theravili, Thun theravili Sinhalen, Sinhala Random Name genarate

Developed by @dotLK from sasindu (c) 8:38 AM 1/31/2024


# Installation
```console
pip install iiyo
```


# API Usage
```console
>>> import iiyo

>>> printquin(())
>>> ['Avihinsaka uwathy','Nihada Mawatha ','Palu Niwahana']

#male Name with address
>>> print(malename())
>>> ['Thilak jayasuriya','Cross Road','Colombo2']



------

Check out: https://www.youtube.com/@sasindu

You can use

* github.com/dotlk/iiyo