def colombo(num):
    match num:        
        case 1:
            return "Kotuwa"
        case 2:
            return "Kompacha Vidiya"
        case 3:
            return "Kollupitiya"
        case 4:
            return "Bambalapitiya"
        case 5:
            return "Hawlok Town"
        case 6:
            return "Wellawaththa"
        case 7:
            return "Kuruduwaththa"
        case 8:
            return "Dematagoda"
        case 9:
            return "Borella"
        case 10:
            return "Maradana"
        case 11:
            return "Pitakotuwa"
        case 12:
            return "Aluthkade"
        case 13:
            return "Kotchtchikade"
        case 14:
            return "Grandpass"
        case 15:
            return "Mattakkuliya"
        case default:
            return "Nothing"




